import streamlit as st

class Sidebar:

    MODEL_OPTIONS = ["gpt-4", "gpt-3.5-turbo"]

    TEMPERATURE_MIN_VALUE = 0.0
    TEMPERATURE_MAX_VALUE = 1.0
    TEMPERATURE_DEFAULT_VALUE = 0.0
    TEMPERATURE_STEP = 0.01

    MAX_TOKENS_MIN_VALUE = 500
    MAX_TOKENS_MAX_VALUE = 5000
    MAX_TOKENS_DEFAULT_VALUE = 500
    MAX_TOKENS_STEP = 100

    @staticmethod
    def about():
        about = st.sidebar.expander("🧠 About Robby ")
        sections = [
            "#### Robby is an AI chatbot with a conversational memory, designed to allow users to discuss their data in a more intuitive way. 📄",
            "#### It uses large language models to provide users with natural language interactions about user data content. 🌐",
            "#### Powered by [Langchain](https://github.com/hwchase17/langchain), [OpenAI](https://platform.openai.com/docs/models/gpt-3-5) and [Streamlit](https://github.com/streamlit/streamlit) ⚡",
            "#### Source code: [yvann-hub/Robby-chatbot](https://github.com/yvann-hub/Robby-chatbot)",
        ]
        for section in sections:
            about.write(section)

    @staticmethod
    def reset_chat_button():
        if st.button("Reset chat"):
            st.session_state["reset_chat"] = True
        st.session_state.setdefault("reset_chat", False)

    def model_selector(self):
        model = st.selectbox(label="Model", options=self.MODEL_OPTIONS)
        st.session_state["model"] = model

    def temperature_slider(self):
        temperature = st.slider(
            label="Temperature",
            min_value=self.TEMPERATURE_MIN_VALUE,
            max_value=self.TEMPERATURE_MAX_VALUE,
            value=self.TEMPERATURE_DEFAULT_VALUE,
            step=self.TEMPERATURE_STEP,
        )
        st.session_state["temperature"] = temperature

    def max_tokens_slider(self):
        max_tokens = st.slider(
            label="Max tokens",
            min_value=self.MAX_TOKENS_MIN_VALUE,
            max_value=self.MAX_TOKENS_MAX_VALUE,
            value=self.MAX_TOKENS_DEFAULT_VALUE,
            step=self.MAX_TOKENS_STEP,

        )
        st.session_state["max_tokens"] = max_tokens
        
    def show_options(self):
        with st.sidebar.expander("🛠️ Paramètrage", expanded=False):

            self.reset_chat_button()
            self.model_selector()
            self.temperature_slider()
            self.max_tokens_slider()
            st.session_state.setdefault("model", self.MODEL_OPTIONS[0])
            st.session_state.setdefault("temperature", self.TEMPERATURE_DEFAULT_VALUE)
            st.session_state.setdefault("max_tokens", self.MAX_TOKENS_DEFAULT_VALUE)

    